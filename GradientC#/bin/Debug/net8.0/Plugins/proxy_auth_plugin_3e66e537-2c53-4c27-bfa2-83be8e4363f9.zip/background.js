
var config = {
	mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "rg-15882.sp4.ovh",
            port: parseInt(11003)
        },
        bypassList: []
	}
};

chrome.proxy.settings.set({ value: config, scope: "regular" }, function() { });

function callbackFn(details)
{
	return {
		authCredentials:
		{
			username: "4stU3vHrR_2",
			password: "dElpw0xNc4Cb"
		}
	};
}

chrome.webRequest.onAuthRequired.addListener(
	callbackFn,

	{ urls:["<all_urls>"] },
    ['blocking']
);